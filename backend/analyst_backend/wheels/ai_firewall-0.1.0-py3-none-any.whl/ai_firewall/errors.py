"""Firewall exceptions."""


class PromptInjectionError(Exception):
    """Raised by ``Firewall.guard_input`` in enforce mode when a prompt is blocked
    or challenged. Carries the ``Detection`` and the ``action`` taken."""

    def __init__(self, detection, action):
        self.detection = detection
        self.action = action
        super().__init__(
            f"Prompt injection {action}: "
            f"severity={getattr(detection, 'severity', None)}, "
            f"categories={getattr(detection, 'matched_categories', ())}"
        )


class DocumentBlockedError(Exception):
    """Raised when a document fails an enforced ingestion scan."""

    def __init__(self, detection):
        self.detection = detection
        super().__init__(
            f"Document blocked: severity={getattr(detection, 'severity', None)}, "
            f"categories={getattr(detection, 'matched_categories', ())}"
        )
