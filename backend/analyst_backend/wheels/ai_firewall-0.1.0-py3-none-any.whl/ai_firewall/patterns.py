"""The single canonical pattern library.

Consolidated from the five teammate files and hardened against the false-positives and
false-negatives found in the empirical audit:

  * verb+object / verb+context gating so bare tokens ("Dan", "eval()", "developer
    mode") no longer false-trigger;
  * bounded filler tolerance ("ignore THE previous instructions") so plain-English
    attacks are no longer missed;
  * category-weighted severity instead of a raw match count.

Each entry is (name, regex, category). Patterns are case-insensitive and DOTALL.
``_F`` is a BOUNDED filler class used between a trigger verb and its object — bounded
quantifiers keep matching linear-time (no ReDoS).
"""

import re

# --- categories ------------------------------------------------------------------
INSTRUCTION_OVERRIDE = "instruction_override"
PROMPT_EXTRACTION = "prompt_extraction"
ROLE_HIJACK = "role_hijack"
SECURITY_BYPASS = "security_bypass"
DATA_EXFILTRATION = "data_exfiltration"
CODE_EXECUTION = "code_execution"
DELIMITER_SPOOFING = "delimiter_spoofing"
SOCIAL_ENGINEERING = "social_engineering"
ENCODING_OBFUSCATION = "encoding_obfuscation"

# Base severity per category. Exfiltration is the crown-jewel risk -> critical.
SEVERITY = {
    INSTRUCTION_OVERRIDE: "high",
    PROMPT_EXTRACTION: "high",
    ROLE_HIJACK: "high",
    SECURITY_BYPASS: "high",
    DATA_EXFILTRATION: "critical",
    CODE_EXECUTION: "high",
    DELIMITER_SPOOFING: "high",
    SOCIAL_ENGINEERING: "high",
    ENCODING_OBFUSCATION: "medium",
}

# Bounded filler between a trigger verb and its object: word chars, whitespace, and a
# little punctuation (comma/period/hyphen). Excludes quotes/brackets/? on purpose so
# fillers don't run across clause boundaries.
_F = r"[\w\s,.-]"

PATTERNS = [
    # ---- instruction override -----------------------------------------------------
    ("override.verb_object",
     r"\b(?:ignore|disregard|forget|override|skip|drop)\b" + _F + r"{0,25}?\b"
     r"(?:instructions?|prompts?|rules?|directives?|guidelines?|context|"
     r"everything\s+(?:you\s+(?:were\s+told|know|learned)|above|prior|previous)|"
     r"prior\s+context)\b",
     INSTRUCTION_OVERRIDE),
    ("override.stop_following",
     r"\bstop\s+(?:following|obeying|adhering\s+to)\b" + _F + r"{0,15}?"
     r"(?:instructions?|rules?|guidelines?|directives?)",
     INSTRUCTION_OVERRIDE),
    ("override.do_not_follow",
     r"\b(?:do\s+not|don'?t)\s+(?:follow|obey|adhere\s+to)\b" + _F + r"{0,20}?"
     r"(?:instructions?|rules?|guidelines?|directives?|prompt)",
     INSTRUCTION_OVERRIDE),

    # ---- prompt / instruction extraction ------------------------------------------
    ("extract.reveal_prompt",
     r"\b(?:reveal|show|print|repeat|expose|leak|dump|return|output|display|"
     r"reproduce|tell\s+me|give\s+me)\b" + _F + r"{0,20}?\b"
     r"(?:system\s+prompt|hidden\s+(?:instructions?|prompts?|rules?)|"
     r"initial\s+(?:instructions?|prompt)|original\s+(?:instructions?|prompt)|"
     r"the\s+prompt|your\s+(?:instructions?|prompt|guidelines?))\b",
     PROMPT_EXTRACTION),
    ("extract.what_is_prompt",
     r"\bwhat(?:'?s| is| are)\s+(?:your\s+)?"
     r"(?:system\s+prompt|initial\s+(?:instructions?|prompt)|"
     r"original\s+(?:instructions?|prompt)|hidden\s+(?:instructions?|prompt))\b",
     PROMPT_EXTRACTION),
    ("extract.repeat_above",
     r"\brepeat\s+(?:the\s+)?(?:words?|text|sentence|everything|message)\s+"
     r"(?:above|before|prior)\b",
     PROMPT_EXTRACTION),

    # ---- role / persona hijack ----------------------------------------------------
    ("role.act_as",
     r"\bact\s+as\s+(?:an?\s+)?(?:administrator|admin|root|superuser|developer|"
     r"unrestricted|uncensored|evil|hacker|dan)\b",
     ROLE_HIJACK),
    ("role.you_are_now",
     r"\byou\s+are\s+(?:now\s+)?(?:an?\s+)?(?:unrestricted|uncensored|jailbroken|dan|"
     r"evil|free|a\s+different)\b",
     ROLE_HIJACK),
    ("role.pretend",
     r"\bpretend\s+(?:you\s+)?(?:are|have\s+no|to\s+be)\b" + _F + r"{0,20}?"
     r"(?:restrictions?|limits?|rules?|unrestricted|no\s+guidelines?|"
     r"someone\s+else|a\s+different)",
     ROLE_HIJACK),
    ("role.roleplay",
     r"\broleplay\s+as\b",
     ROLE_HIJACK),
    # DAN only with explicit jailbreak context — never the bare name.
    ("role.dan",
     r"\bdan\b\s*(?:mode|prompt|jailbreak)|\b(?:enable|activate|enter)\s+dan\b",
     ROLE_HIJACK),
    # Privilege-escalation "modes" — only with activation framing, not ops vocabulary.
    ("role.priv_mode",
     r"\b(?:enable|enter|activate|switch\s+to|go\s+into|you\s+are\s+(?:now\s+)?in)\s+"
     r"(?:god|sudo|root|admin|dev|developer)\s+mode\b",
     ROLE_HIJACK),

    # ---- security bypass / jailbreak ----------------------------------------------
    ("bypass.bypass",
     r"\bbypass\b" + _F + r"{0,15}?"
     r"(?:safety|security|restrictions?|content\s+(?:filter|policy)|"
     r"guardrails?|filters?|moderation)",
     SECURITY_BYPASS),
    ("bypass.disable",
     r"\bdisable\b" + _F + r"{0,15}?"
     r"(?:security|safety|filters?|guardrails?|content\s+policy|moderation)",
     SECURITY_BYPASS),
    ("bypass.jailbreak",
     r"\bjailbreak\b",
     SECURITY_BYPASS),
    # "developer mode" only as an activation request, not as ops vocabulary.
    ("bypass.dev_mode",
     r"\b(?:enable|activate|enter|turn\s+on|switch\s+to|go\s+into)\s+developer\s+mode\b"
     r"|\bdeveloper\s+mode\s*[:=]",
     SECURITY_BYPASS),

    # ---- data exfiltration --------------------------------------------------------
    ("exfil.verb_object",
     r"\b(?:exfiltrate|leak|steal|smuggle|dump)\b" + _F + r"{0,30}?"
     r"(?:data|information|context|content|memory|history|database|records?|"
     r"customers?|users?|secrets?|credentials?|prompt)",
     DATA_EXFILTRATION),
    ("exfil.send_to",
     r"\b(?:send|forward|transmit|post|upload|email)\b" + _F + r"{0,40}?"
     r"(?:user\s+data|credentials?|api\s+keys?|passwords?|secrets?|tokens?|"
     r"database|the\s+context|system\s+prompt|all\s+(?:the\s+)?(?:user\s+)?data)\b"
     + _F + r"{0,30}?\b(?:to|at|http|server|webhook|external)\b",
     DATA_EXFILTRATION),

    # ---- code execution -----------------------------------------------------------
    ("code.run_following",
     r"\b(?:execute|run|eval|evaluate|invoke)\b" + _F + r"{0,20}?"
     r"(?:the\s+following|arbitrary|malicious|untrusted|this)\b" + _F + r"{0,15}?"
     r"(?:code|command|script|payload|shell)",
     CODE_EXECUTION),
    # Dangerous sink, but only when imperatively invoked (so "eval() docs" is safe).
    ("code.dangerous_sink",
     r"\b(?:run|execute|invoke)\b" + _F + r"{0,15}?"
     r"(?:os\.system|subprocess|eval\s*\(|exec\s*\(|rm\s+-rf|/bin/sh|bash\s+-c)",
     CODE_EXECUTION),

    # ---- delimiter / boundary spoofing --------------------------------------------
    ("delim.angle",
     r"<\s*/?\s*(?:system|user|assistant|instruction|inst|sys)\s*>",
     DELIMITER_SPOOFING),
    ("delim.bracket",
     r"\[\s*/?\s*(?:INST|SYS|SYSTEM|ADMIN)\s*\]",
     DELIMITER_SPOOFING),
    ("delim.sys_markers",
     r"<<\s*/?\s*SYS\s*>>|<\|\s*(?:system|im_start|im_end|endoftext)\s*\|>",
     DELIMITER_SPOOFING),

    # ---- social engineering -------------------------------------------------------
    ("social.purposes",
     r"\b(?:for|just)\s+(?:educational|research|academic|testing|hypothetical)\s+"
     r"purposes?\b" + _F + r"{0,30}?"
     r"(?:ignore|bypass|disable|reveal|pretend|forget|override)",
     SOCIAL_ENGINEERING),
    ("social.this_is_a_test",
     r"\bthis\s+is\s+(?:just\s+)?(?:a|an)\s+"
     r"(?:test|simulation|game|hypothetical|roleplay|exercise)\b" + _F + r"{0,30}?"
     r"(?:ignore|disable|bypass|reveal|pretend|forget|override)",
     SOCIAL_ENGINEERING),

    # ---- encoding / obfuscation ---------------------------------------------------
    ("encode.base64",
     r"\bbase64\b\s*(?:decode|encode)?\s*(?:this|the\s+following|:)",
     ENCODING_OBFUSCATION),
    ("encode.rot_hex",
     r"\brot13\b|\bhex\s+encoded?\s+instruction",
     ENCODING_OBFUSCATION),
]

# (name, compiled_regex, category)
COMPILED = [
    (name, re.compile(rx, re.IGNORECASE | re.DOTALL), cat)
    for name, rx, cat in PATTERNS
]
