"""Policy — how detections translate into actions, and the monitor/enforce dial."""

from dataclasses import dataclass
from enum import Enum


class Action(str, Enum):
    ALLOW = "allow"
    FLAG = "flag"
    CHALLENGE = "challenge"
    BLOCK = "block"


class Mode(str, Enum):
    MONITOR = "monitor"   # detect + log, never raise (safe first rollout)
    ENFORCE = "enforce"   # raise on block/challenge


_SEV_ORDER = {None: 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


@dataclass
class Policy:
    mode: Mode = Mode.MONITOR
    block_threshold: str = "high"
    challenge_threshold: str = "medium"
    flag_threshold: str = "low"
    max_input_length: int = 10_000
    # Separate, larger cap for document / retrieval / tool-output surfaces. Callers
    # ingesting bigger documents must chunk before calling — this is a hard limit.
    max_document_length: int = 100_000
    redaction_placeholder: str = "[REMOVED]"
    # 0 = log no message content (privacy-safe default — only metadata is logged).
    log_preview_chars: int = 0

    def __post_init__(self):
        # ergonomics: accept Policy(mode="enforce") as well as Mode.ENFORCE
        if isinstance(self.mode, str):
            self.mode = Mode(self.mode)


def decide(severity: str | None, policy: Policy) -> Action:
    """Map a severity to an Action given the policy's thresholds."""
    score = _SEV_ORDER.get(severity, 0)
    if score == 0:
        return Action.ALLOW
    if score >= _SEV_ORDER[policy.block_threshold]:
        return Action.BLOCK
    if score >= _SEV_ORDER[policy.challenge_threshold]:
        return Action.CHALLENGE
    if score >= _SEV_ORDER[policy.flag_threshold]:
        return Action.FLAG
    return Action.ALLOW
