"""ai_firewall — framework-agnostic prompt-injection firewall.

Pure-Python core (zero runtime dependencies). Optional framework adapters live in
``ai_firewall.integrations`` and are imported lazily.
"""

from .firewall import Firewall
from .detector import Detector, Detection
from .policy import Policy, Mode, Action, decide
from .errors import PromptInjectionError, DocumentBlockedError
from .gateway import SecureGateway

__all__ = [
    "Firewall",
    "SecureGateway",
    "Detector",
    "Detection",
    "Policy",
    "Mode",
    "Action",
    "decide",
    "PromptInjectionError",
    "DocumentBlockedError",
]

__version__ = "0.2.0"
