"""The detection kernel — the swappable seam.

``Detector.detect`` is the single interface the rest of the library depends on. A
future semantic / LLM-judge detector can implement the same ``detect(text) ->
Detection`` signature and be dropped in with no caller changes.

Detection runs the pattern library against several *projections* of the input:
the normalized text, a confusable-folded shadow (defeats homoglyphs), and a
leet-folded shadow (defeats `r3v34l`-style evasion). A pattern matching ANY
projection counts as a hit. Folds are detection-only; user text is never mutated here.
"""

from dataclasses import dataclass

from .normalize import normalize_text
from .confusables import fold_confusables, fold_leet
from .patterns import COMPILED, SEVERITY

_SEV_ORDER = {None: 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
_SEV_RISK = {None: 0, "low": 20, "medium": 45, "high": 75, "critical": 95}


@dataclass(frozen=True)
class Detection:
    """Result of a scan. ``is_suspicious`` is the headline; the rest explains why."""
    is_suspicious: bool
    matched_patterns: tuple = ()
    matched_categories: tuple = ()
    severity: str | None = None
    risk_score: int = 0


class Detector:
    def __init__(self, patterns=COMPILED, fold_confusables_pass=True,
                 fold_leet_pass=True):
        # public so consumers (e.g. the Firewall redactor) can reuse the same rules
        self.patterns = patterns
        self._fold_confusables = fold_confusables_pass
        self._fold_leet = fold_leet_pass

    def projections(self, normalized: str) -> list[str]:
        """Return length-aligned views of already-normalized text: the text itself,
        a confusable-folded shadow, and leet-folded shadows. Folds are 1:1 codepoint
        maps, so a match offset on any projection is the same offset in ``normalized``.
        Public so the redactor can reuse it to blank obfuscated spans by offset."""
        projections = [normalized]
        folded = normalized
        if self._fold_confusables:
            folded = fold_confusables(normalized)
            if folded != normalized:
                projections.append(folded)
        if self._fold_leet:
            for base in (folded, normalized):
                leet = fold_leet(base)
                if leet != base and leet not in projections:
                    projections.append(leet)
        return projections

    def detect(self, text) -> Detection:
        if not isinstance(text, str):
            text = str(text)
        projections = self.projections(normalize_text(text))

        names, categories = [], []
        for name, regex, category in self.patterns:
            if any(regex.search(p) for p in projections):
                names.append(name)
                if category not in categories:
                    categories.append(category)

        if not names:
            return Detection(is_suspicious=False)

        severity = self._aggregate_severity(categories)
        return Detection(
            is_suspicious=True,
            matched_patterns=tuple(names),
            matched_categories=tuple(categories),
            severity=severity,
            risk_score=self._risk(severity, categories),
        )

    @staticmethod
    def _aggregate_severity(categories) -> str | None:
        best = None
        for c in categories:
            s = SEVERITY.get(c, "low")
            if _SEV_ORDER[s] > _SEV_ORDER[best]:
                best = s
        return best

    @staticmethod
    def _risk(severity, categories) -> int:
        base = _SEV_RISK[severity]
        breadth_bonus = 5 * max(0, len(set(categories)) - 1)
        return min(100, base + breadth_bonus)
