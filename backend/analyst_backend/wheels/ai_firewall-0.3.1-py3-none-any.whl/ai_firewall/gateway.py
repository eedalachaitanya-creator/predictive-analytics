"""SecureGateway — a reusable, framework-agnostic secure gateway for LLM apps.

Drop ONE object in front of any LLM so every prompt and response is guarded —
no code path can reach the model directly:

    from ai_firewall import SecureGateway, Policy

    gw = SecureGateway(
        llm=my_llm_callable,                 # any callable: (prompt, **kw) -> str
        policy=Policy(mode="enforce"),       # monitor (log) or enforce (block)
        protect=[SYSTEM_PROMPT, API_KEY],    # strings that must never leak in output
    )

    answer = gw.chat("How many customers are high risk?")
    #   guard_input(prompt)  ->  llm(prompt)  ->  guard_output(response)  ->  strip protected

RAG / agent surfaces (call them where the data enters/leaves the model):

    gw.ingest_document(doc)        # sanitize a doc before embedding   (RAG ingest)
    gw.scan_document(doc)          # verdict: should I embed this?      (RAG ingest)
    gw.filter_context(chunks)      # sanitize retrieved chunks          (RAG retrieval)
    gw.guard_tool(tool_output)     # sanitize tool/DB/scraped text      (agent tools)

The gateway only depends on the ``Firewall`` API, so it works with OpenAI,
Anthropic, LangChain, CrewAI, a raw HTTP client — anything.
"""

from .firewall import Firewall
from .policy import Policy
from .errors import PromptInjectionError


class SecureGateway:
    """One choke-point that funnels every model input and output through the
    firewall. Ingress (the prompt) may block in enforce mode; egress (the
    response) is always sanitized, never blocked."""

    def __init__(self, llm=None, *, firewall=None, policy=None,
                 protect=None, on_blocked_input=None):
        """
        Parameters
        ----------
        llm : callable | None
            ``(prompt: str, **kwargs) -> str``. May be set later or passed per call.
        firewall : Firewall | None
            A pre-configured Firewall. If omitted, one is built from ``policy``.
        policy : Policy | None
            Policy for a freshly-built firewall (ignored if ``firewall`` is given).
        protect : list[str] | None
            Strings that must NEVER appear verbatim in the output — e.g. the system
            prompt, API keys, secrets. Any occurrence is redacted from the response.
        on_blocked_input : callable | None
            ``(PromptInjectionError) -> str``. If set, a blocked prompt returns this
            value instead of raising — convenient for returning a safe refusal.
        """
        self.firewall = firewall or Firewall(policy or Policy())
        self.llm = llm
        self.protect = [p for p in (protect or []) if p]
        self.on_blocked_input = on_blocked_input

    # ── the choke-point ──────────────────────────────────────────────────────
    def chat(self, prompt, *, llm=None, **llm_kwargs):
        """Guard the prompt, call the LLM, guard the response. The ONLY way the
        app should talk to the model."""
        call = llm or self.llm
        if call is None:
            raise ValueError(
                "SecureGateway.chat needs an llm callable — pass llm=... or set it "
                "on the gateway (SecureGateway(llm=...))."
            )
        try:
            safe_prompt = self.firewall.guard_input(prompt)
        except PromptInjectionError as exc:
            if self.on_blocked_input is not None:
                return self.on_blocked_input(exc)
            raise
        response = call(safe_prompt, **llm_kwargs)
        return self.guard_response(response)

    # ── egress ───────────────────────────────────────────────────────────────
    def guard_response(self, text) -> str:
        """Sanitize a model response: redact echoed injection (``guard_output``)
        then strip any ``protect`` secret that leaked. Never raises."""
        if not isinstance(text, str):
            text = str(text)
        out = self.firewall.guard_output(text)
        placeholder = self.firewall.policy.redaction_placeholder
        for secret in self.protect:
            if secret in out:
                out = out.replace(secret, placeholder)
        return out

    # ── RAG / agent surfaces (thin pass-throughs — one object guards everything)
    def scan_document(self, text):
        """RAG ingest verdict — should this document be embedded?"""
        return self.firewall.scan_document(text)

    def ingest_document(self, text) -> str:
        """RAG ingest — embed-safe (sanitized) text."""
        return self.firewall.sanitize_document(text)

    def filter_context(self, chunks, **kwargs):
        """RAG retrieval — sanitize retrieved chunks before they enter the context."""
        return self.firewall.filter_retrieval(chunks, **kwargs)

    def guard_tool(self, text) -> str:
        """Agent tools — sanitize tool / DB / scraped text fed back to the model."""
        return self.firewall.guard_tool_output(text)
