"""Optional, lazily-imported framework adapters.

Importing this package never imports langchain/crewai. Each adapter pulls its
framework in only when actually used, so the core stays dependency-free.
"""

from .generic import guard_callable

__all__ = ["guard_callable"]
