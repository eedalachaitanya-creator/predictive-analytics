"""Framework-agnostic guard decorator.

Wraps any callable (a plain tool function, an agent step, a CrewAI tool's ``_run``)
so that string inputs pass through ``guard_input`` and an optional string result is
sanitized via ``guard_tool_output``. Works everywhere because it only relies on the
``Firewall`` API, not on any framework.
"""

import functools


def guard_callable(firewall, guard_args: bool = True, sanitize_result: bool = False):
    """Decorator factory.

    Parameters
    ----------
    firewall : Firewall
        The configured firewall to apply.
    guard_args : bool
        Run ``guard_input`` over every string positional/keyword argument. In enforce
        mode this raises ``PromptInjectionError`` before the wrapped callable runs.
    sanitize_result : bool
        Run ``guard_tool_output`` over a string return value (redacts injected
        payloads). Never raises — tool output is attacker-influenced, not the request.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            if guard_args:
                args = tuple(
                    firewall.guard_input(a) if isinstance(a, str) else a for a in args
                )
                kwargs = {
                    k: (firewall.guard_input(v) if isinstance(v, str) else v)
                    for k, v in kwargs.items()
                }
            result = fn(*args, **kwargs)
            if sanitize_result and isinstance(result, str):
                result = firewall.guard_tool_output(result)
            return result
        return wrapper
    return decorator
