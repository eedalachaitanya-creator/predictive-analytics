"""LangChain / LangGraph adapter.

Binds ``guard_input`` into an LCEL ``Runnable`` so it can be piped ahead of a prompt:
``make_guard_runnable(fw) | prompt | llm``. langchain-core is imported lazily, so the
core library never depends on it.
"""


def make_guard_runnable(firewall):
    """Return a ``RunnableLambda`` that guards a string input through the firewall."""
    try:
        from langchain_core.runnables import RunnableLambda
    except ImportError as exc:  # pragma: no cover - exercised when extra not installed
        raise ImportError(
            "make_guard_runnable requires langchain-core. "
            "Install it with: pip install 'ai-firewall[langchain]'"
        ) from exc
    return RunnableLambda(firewall.guard_input)
