"""SessionMonitor — behavioral escalation across a conversation/session.

A single borderline message may be innocent; a *stream* of them from one session is
a probing campaign. The monitor counts suspicious verdicts per session and, past a
threshold, recommends escalating that session's risk — so a slow drip of low/medium
attempts is treated as the attack it is. In-memory and dependency-free; a consumer
can persist it behind the same tiny interface (record / assessment / reset).
"""


class SessionMonitor:
    def __init__(self, *, threshold: int = 3, escalate_to: str = "high",
                 max_sessions: int = 50_000):
        self.threshold = threshold
        self.escalate_to = escalate_to
        self._max = max_sessions
        self._counts: dict = {}

    def record(self, session_id, detection) -> None:
        """Count this message if its verdict was suspicious."""
        if not getattr(detection, "is_suspicious", False):
            return
        self._counts[session_id] = self._counts.get(session_id, 0) + 1
        if len(self._counts) > self._max:        # crude bound — evict the oldest key
            self._counts.pop(next(iter(self._counts)), None)

    def count(self, session_id) -> int:
        return self._counts.get(session_id, 0)

    def assessment(self, session_id) -> str | None:
        """Escalated severity for this session, or None if under the threshold."""
        return self.escalate_to if self._counts.get(session_id, 0) >= self.threshold else None

    def reset(self, session_id) -> None:
        self._counts.pop(session_id, None)
